import pygame


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.cell_size = 60

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        for i in range(self.height):
            for j in range(self.width):
                pygame.draw.rect(screen, (255, 255, 255),
                                 (self.cell_size * j, self.cell_size * i, self.cell_size,
                                  self.cell_size), 1)
        #pygame.draw.circle(screen, (0, 200, 64), (20, 13), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (40, 13), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (20, 29), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (40, 29), 13)
        #pygame.draw.line(screen, (90, 4, 18), (30, 37), (30, 60), 3)

        pygame.draw.circle(screen, (0, 200, 64), (260, 133), 13)
        pygame.draw.circle(screen, (0, 200, 64), (280, 133), 13)
        pygame.draw.circle(screen, (0, 200, 64), (260, 149), 13)
        pygame.draw.circle(screen, (0, 200, 64), (280, 149), 13)
        pygame.draw.line(screen, (90, 4, 18), (270, 157), (270, 180), 3)

        pygame.draw.circle(screen, (0, 200, 64), (140, 373), 13)
        pygame.draw.circle(screen, (0, 200, 64), (160, 373), 13)
        pygame.draw.circle(screen, (0, 200, 64), (140, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (160, 389), 13)
        pygame.draw.line(screen, (90, 4, 18), (150, 397), (150, 420), 3)

        pygame.draw.circle(screen, (0, 200, 64), (680, 373), 13)
        pygame.draw.circle(screen, (0, 200, 64), (700, 373), 13)
        pygame.draw.circle(screen, (0, 200, 64), (680, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (700, 389), 13)
        pygame.draw.line(screen, (90, 4, 18), (690, 397), (690, 420), 3)

        pygame.draw.circle(screen, (0, 200, 64), (500, 793), 13)
        pygame.draw.circle(screen, (0, 200, 64), (520, 793), 13)
        pygame.draw.circle(screen, (0, 200, 64), (500, 809), 13)
        pygame.draw.circle(screen, (0, 200, 64), (520, 809), 13)
        pygame.draw.line(screen, (90, 4, 18), (510, 817), (510, 840), 3)

        pygame.draw.line(screen, (125, 125, 125), (330, 600), (330, 660), 5)
        pygame.draw.line(screen, (125, 125, 125), (750, 780), (750, 840), 5)
        pygame.draw.line(screen, (125, 125, 125), (750, 840), (750, 900), 5)

        pi = 3.14
        pygame.draw.arc(screen, (255, 255, 0),
                (100, 480, 280, 100),
                0, pi, 15)
        pygame.draw.arc(screen, (255, 255, 0),
                (400, 70, 230, 100),
                0, pi, 15)

        pygame.draw.rect(screen, (253, 134, 138), (1, 1, 58, 58))
        pygame.draw.rect(screen, (134, 167, 253), (901, 901, 58, 58))
            

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('поле')
    size = width, height = 960, 960
    screen = pygame.display.set_mode(size)


    board = Board(16, 16)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill((225, 225, 0))
        board.render(screen)
        pygame.display.flip()
