import pygame


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.cell_size = 60

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        for i in range(self.height):
            for j in range(self.width):
                pygame.draw.rect(screen, (255, 255, 255),
                                 (self.cell_size * j, self.cell_size * i, self.cell_size,
                                  self.cell_size), 1)
        #pygame.draw.circle(screen, (0, 200, 64), (20, 13), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (40, 13), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (20, 29), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (40, 29), 13)
        #pygame.draw.line(screen, (90, 4, 18), (30, 37), (30, 60), 3)

        pygame.draw.rect(screen, (208, 208, 205), (1, 301, 58, 58))
        
        pygame.draw.rect(screen, (208, 208, 205), (61, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 241, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 181, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 121, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 361, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 421, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 481, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 541, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 601, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (61, 661, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (121, 661, 58, 58))
        
        pygame.draw.rect(screen, (208, 208, 205), (121, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (181, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (241, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (301, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (361, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (421, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (481, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (541, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (541, 361, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (541, 421, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (541, 481, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (541, 541, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (481, 541, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (601, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (661, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (721, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (721, 241, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (781, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (781, 241, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (841, 301, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (841, 361, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (841, 421, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (841, 481, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (841, 541, 58, 58))
        pygame.draw.rect(screen, (208, 208, 205), (901, 301, 58, 58))

        pygame.draw.circle(screen, (0, 200, 64), (260, 149), 13)
        pygame.draw.circle(screen, (0, 200, 64), (280, 149), 13)
        pygame.draw.circle(screen, (0, 200, 64), (260, 133), 13)
        pygame.draw.circle(screen, (0, 200, 64), (280, 133), 13)
        pygame.draw.line(screen, (90, 4, 18), (270, 157), (270, 180), 3)

        pygame.draw.circle(screen, (0, 200, 64), (140, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (160, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (140, 373), 13)
        pygame.draw.circle(screen, (0, 200, 64), (160, 373), 13)
        pygame.draw.line(screen, (90, 4, 18), (150, 397), (150, 420), 3)

        pygame.draw.circle(screen, (0, 200, 64), (680, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (700, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (680, 373), 13)
        pygame.draw.circle(screen, (0, 200, 64), (700, 373), 13)
        pygame.draw.line(screen, (90, 4, 18), (690, 397), (690, 420), 3)

        pygame.draw.circle(screen, (0, 200, 64), (450, 809), 13)
        pygame.draw.circle(screen, (0, 200, 64), (470, 809), 13)
        pygame.draw.circle(screen, (0, 200, 64), (450, 793), 13)
        pygame.draw.circle(screen, (0, 200, 64), (470, 793), 13)
        pygame.draw.line(screen, (90, 4, 18), (460, 817), (460, 840), 3)

        pygame.draw.circle(screen, (0, 200, 64), (500, 759), 13)
        pygame.draw.circle(screen, (0, 200, 64), (520, 759), 13)
        pygame.draw.circle(screen, (0, 200, 64), (500, 743), 13)
        pygame.draw.circle(screen, (0, 200, 64), (520, 743), 13)
        pygame.draw.line(screen, (90, 4, 18), (510, 767), (510, 790), 3)


        pygame.draw.rect(screen, (0, 255, 255), (75, 30, 30, 90))
        pygame.draw.polygon(screen, (0, 0, 0), ((75, 30), (90, 0), (105, 30)))
        pygame.draw.rect(screen, (255, 255, 255), (85, 40, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 60, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 80, 10, 10))

        pygame.draw.rect(screen, (0, 255, 255), (735, 30, 90, 210))
        pygame.draw.polygon(screen, (0, 0, 0), ((735, 30), (780, 0), (825, 30)))
        pygame.draw.rect(screen, (255, 255, 255), (745, 40, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 60, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 80, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 100, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 120, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 140, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 160, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 180, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (745, 200, 10, 10))

        pygame.draw.rect(screen, (255, 255, 255), (775, 40, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 60, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 80, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 100, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 120, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 140, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 160, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 180, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (775, 200, 10, 10))

        pygame.draw.rect(screen, (255, 255, 255), (805, 40, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 60, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 80, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 100, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 120, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 140, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 160, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 180, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (805, 200, 10, 10))
                         
        pygame.draw.rect(screen, (0, 255, 255), (135, 750, 30, 90))
        pygame.draw.polygon(screen, (0, 0, 0), ((135, 750), (150, 720), (165, 750)))
        pygame.draw.rect(screen, (255, 255, 255), (145, 760, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (145, 780, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (145, 800, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (145, 820, 10, 10))

        pygame.draw.rect(screen, (0, 255, 255), (75, 750, 30, 150))
        pygame.draw.polygon(screen, (0, 0, 0), ((75, 750), (90, 720), (105, 750)))
        pygame.draw.rect(screen, (255, 255, 255), (85, 760, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 780, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 800, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 820, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 840, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 860, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 880, 10, 10))

        pygame.draw.rect(screen, (0, 255, 255), (855, 630, 30, 90))
        pygame.draw.polygon(screen, (0, 0, 0), ((855, 630), (870, 600), (885, 630)))
        pygame.draw.rect(screen, (255, 255, 255), (865, 640, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (865, 660, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (865, 680, 10, 10))
        
        pygame.draw.rect(screen, (0, 255, 255), (435, 520, 200, 200))
        pygame.draw.polygon(screen, (0, 0, 0), ((435, 520), (535, 480), (635, 520)))
        pygame.draw.rect(screen, (255, 255, 255), (445, 580, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (445, 560, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (445, 540, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (445, 600, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (445, 640, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (445, 660, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (445, 680, 10, 10))

        pygame.draw.rect(screen, (255, 255, 255), (530, 580, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (530, 560, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (530, 540, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (530, 600, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (530, 640, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (530, 660, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (530, 680, 10, 10))

        pygame.draw.rect(screen, (255, 255, 255), (615, 580, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (615, 560, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (615, 540, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (615, 600, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (615, 640, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (615, 660, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (615, 680, 10, 10))


        pygame.draw.rect(screen, (0, 255, 255), (315, 460, 90, 200))
        pygame.draw.polygon(screen, (0, 0, 0), ((315, 460), (360, 420), (405, 460)))
        pygame.draw.rect(screen, (255, 255, 255), (340, 500, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (340, 480, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (340, 560, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (340, 580, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (340, 600, 10, 10))

        pygame.draw.rect(screen, (255, 255, 255), (370, 500, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (370, 480, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (370, 560, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (370, 580, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (370, 600, 10, 10))         

        pygame.draw.rect(screen, (255, 255, 255), (615, 680, 10, 10))

        pygame.draw.rect(screen, (253, 134, 138), (1, 1, 58, 58))
        pygame.draw.rect(screen, (134, 167, 253), (901, 901, 58, 58))

        
        

        
if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('поле')
    size = width, height = 960, 960
    screen = pygame.display.set_mode(size)


    board = Board(16, 16)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill((139, 159, 161))
        board.render(screen)
        pygame.display.flip()
