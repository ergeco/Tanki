import pygame


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.cell_size = 60

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        for i in range(self.height):
            for j in range(self.width):
                pygame.draw.rect(screen, (255, 255, 255),
                                 (self.cell_size * j, self.cell_size * i, self.cell_size,
                                  self.cell_size), 1)
        #pygame.draw.circle(screen, (0, 200, 64), (20, 13), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (40, 13), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (20, 29), 13)
        #pygame.draw.circle(screen, (0, 200, 64), (40, 29), 13)
        #pygame.draw.line(screen, (90, 4, 18), (30, 37), (30, 60), 3)

        pygame.draw.circle(screen, (0, 200, 64), (260, 149), 13)
        pygame.draw.circle(screen, (0, 200, 64), (280, 149), 13)
        pygame.draw.circle(screen, (255, 255, 255), (260, 133), 13)
        pygame.draw.circle(screen, (255, 255, 255), (280, 133), 13)
        pygame.draw.line(screen, (90, 4, 18), (270, 157), (270, 180), 3)

        pygame.draw.circle(screen, (0, 200, 64), (140, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (160, 389), 13)
        pygame.draw.circle(screen, (255, 255, 255), (140, 373), 13)
        pygame.draw.circle(screen, (255, 255, 255), (160, 373), 13)
        pygame.draw.line(screen, (90, 4, 18), (150, 397), (150, 420), 3)

        pygame.draw.circle(screen, (0, 200, 64), (680, 389), 13)
        pygame.draw.circle(screen, (0, 200, 64), (700, 389), 13)
        pygame.draw.circle(screen, (255, 255, 255), (680, 373), 13)
        pygame.draw.circle(screen, (255, 255, 255), (700, 373), 13)
        pygame.draw.line(screen, (90, 4, 18), (690, 397), (690, 420), 3)

        pygame.draw.circle(screen, (0, 200, 64), (500, 809), 13)
        pygame.draw.circle(screen, (0, 200, 64), (520, 809), 13)
        pygame.draw.circle(screen, (255, 255, 255), (500, 793), 13)
        pygame.draw.circle(screen, (255, 255, 255), (520, 793), 13)
        pygame.draw.line(screen, (90, 4, 18), (510, 817), (510, 840), 3)


        pygame.draw.rect(screen, (255, 77, 0), (75, 30, 30, 90))
        pygame.draw.polygon(screen, (90, 4, 18), ((75, 30), (90, 0), (105, 30)))
        pygame.draw.polygon(screen, (255, 255, 255), ((82, 15), (90, 0), (98, 15)))
        pygame.draw.rect(screen, (255, 255, 255), (85, 40, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 60, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (85, 80, 10, 10))

        pygame.draw.rect(screen, (255, 77, 0), (855, 630, 30, 90))
        pygame.draw.polygon(screen, (90, 4, 18), ((855, 630), (870, 600), (885, 630)))
        pygame.draw.polygon(screen, (255, 255, 255), ((862, 615), (870, 600), (878, 615)))
        pygame.draw.rect(screen, (255, 255, 255), (865, 640, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (865, 660, 10, 10))
        pygame.draw.rect(screen, (255, 255, 255), (865, 680, 10, 10))
        
        pygame.draw.rect(screen, (255, 77, 0), (435, 570, 30, 27))
        pygame.draw.polygon(screen, (90, 4, 18), ((435, 570), (450, 540), (465, 570)))
        pygame.draw.polygon(screen, (255, 255, 255), ((442, 555), (450, 540), (458, 555)))
        pygame.draw.rect(screen, (255, 255, 255), (445, 580, 10, 10))
        
        # pygame.draw.polygon(screen, (161, 250, 255), ((0, 60), (60, 0), (120, 60)))
        pygame.draw.polygon(screen, (161, 250, 255), ((360, 420), (420, 360), (480, 420)))
        pygame.draw.polygon(screen, (255, 255, 255), ((380, 400), (420, 360), (460, 400)))             
        
        pygame.draw.polygon(screen, (161, 250, 255), ((120, 900), (180, 780), (240, 900)))
        pygame.draw.polygon(screen, (255, 255, 255), ((140, 860), (180, 780), (220, 860)))

        pygame.draw.circle(screen, (161, 250, 255), (660, 120), 118)

        pygame.draw.rect(screen, (253, 134, 138), (1, 1, 58, 58))
        pygame.draw.rect(screen, (134, 167, 253), (901, 901, 58, 58))

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('поле')
    size = width, height = 960, 960
    screen = pygame.display.set_mode(size)


    board = Board(16, 16)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill((91, 225, 240))
        board.render(screen)
        pygame.display.flip()
